const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    const mongoUri = process.env.MONGO_URI;

    if (!mongoUri || mongoUri.includes('<username>') || mongoUri.includes('your_mongodb_atlas')) {
      console.warn('\n⚠️ [Database Warning]: MONGO_URI is not configured with valid credentials in backend/.env');
      console.warn('👉 Please update backend/.env with your actual MongoDB Atlas connection string:\n   MONGO_URI=mongodb+srv://<username>:<password>@cluster0.xxx.mongodb.net/hospital_stock?retryWrites=true&w=majority\n');
    }

    const conn = await mongoose.connect(mongoUri || 'mongodb://127.0.0.1:27017/hospital_stock', {
      serverSelectionTimeoutMS: 5000,
    });

    console.log(`✅ MongoDB Connected Successfully: ${conn.connection.host} [DB: ${conn.connection.name}]`);
    return conn;
  } catch (error) {
    console.error(`❌ MongoDB Connection Error: ${error.message}`);
    console.warn('⚠️ Server will continue running, but database-dependent operations will fail until MONGO_URI is reachable.');
    return null;
  }
};

module.exports = connectDB;
